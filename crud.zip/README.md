# php-CRUD-Generator

## How to use

```
a. letakkan folder php-Crud-Generator pada localhost
b. buka localhost/php-Crud-Generator dari browser
c. pada form "create database connection" isikan dengan benar : hostname #biasanya localhost, 
database name #adalah nama database yang akan di generate kan CRUD nya, database user #biasanya root,
database password #biasanya kalau di windows di kosongkan saja, link project #copykan saja url
yang di tampilkan pada browser. next klik tombol generate config file
d. next pilih tabel, dan tekan generate atau bisa langsung menekan generate All
e. daftar folder yang telah di generate akan muncul pada "Daftar folder"
```


## Cooming Soon

1. Checker for Chmod & Chown (Linux Mode)
2. Security from SQL-injection
3. Just bootstrap table or bootstrap datatables
4. Pagination
5. simple form login
6. menu generator
7. etc

## Update

1. Adding Generate All
2. Adding form for Create connection file from web browser (21 Des 16)
3. Adding Bootstrap Template for Generated file
4. Adding Notif for Generated file (Create, Edit, Delete)


> written with <3 by Me Gandhi Wibowo
