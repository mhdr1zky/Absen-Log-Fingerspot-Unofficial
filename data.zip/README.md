# Absen-Log-Fingerspot-Unofficial
Membuat aplikasi untuk tarik data dari absen log format text txt dan Excel xls
